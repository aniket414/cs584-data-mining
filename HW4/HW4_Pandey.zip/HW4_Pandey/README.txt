Steps to run the code:
1.	Download MovieRecommender.ipynb file
2.	Open JupyterLab on Anaconda Navigator or Google Colab Notebook
3.	On the menu bar click File -> Open -> MovieRecommender.ipynb
4.	Keep the MovieRecommender.py and data file in the same directory
5.	One by one run each cell in the notebook
