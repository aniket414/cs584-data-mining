Steps to run the code:
1.	Download MovieReviewClassification.ipynb file
2.	Open JupyterLab on Anaconda Navigator or Google Colab Notebook
3.	On the menu bar click File -> Open -> MovieReviewClassification.ipynb
4.	Keep the test.dat and train.dat file in the same directory
5.	One by one run each cell in the notebook
