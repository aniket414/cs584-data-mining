Steps to run the code:
1.	Download CreditRiskPrediction.ipynb file
2.	Open JupyterLab on Anaconda Navigator or Google Colab Notebook
3.	On the menu bar click File -> Open -> CreditRiskPrediction.ipynb
4.	Keep the credit_test.csv and credit_train.csv file in the same directory
5.	One by one run each cell in the notebook
