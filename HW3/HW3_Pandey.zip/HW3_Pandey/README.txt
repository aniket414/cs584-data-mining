Steps to run the code:
1.	Download KMeans_Iris.ipynb and KMeans_Digits.ipynb file
2.	Open JupyterLab on Anaconda Navigator or Google Colab Notebook
3.	On the menu bar click File -> Open -> Filename
4.	Keep the KMeans.py and data file in the same directory
5.	One by one run each cell in the notebook
